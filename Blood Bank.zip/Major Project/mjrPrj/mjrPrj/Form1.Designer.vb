﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Donor_Registration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDnrReg = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblUsrNam = New System.Windows.Forms.Label()
        Me.lblPwd = New System.Windows.Forms.Label()
        Me.txtUsrNam = New System.Windows.Forms.TextBox()
        Me.txtPwd = New System.Windows.Forms.TextBox()
        Me.btnRegs = New System.Windows.Forms.Button()
        Me.btnLgn = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDnrReg
        '
        Me.lblDnrReg.AutoSize = True
        Me.lblDnrReg.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDnrReg.Location = New System.Drawing.Point(13, 13)
        Me.lblDnrReg.Name = "lblDnrReg"
        Me.lblDnrReg.Size = New System.Drawing.Size(278, 31)
        Me.lblDnrReg.TabIndex = 0
        Me.lblDnrReg.Text = "Donor Registration"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.mjrPrj.My.Resources.Resources.login_img
        Me.PictureBox1.Location = New System.Drawing.Point(12, 121)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(320, 357)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'lblUsrNam
        '
        Me.lblUsrNam.AutoSize = True
        Me.lblUsrNam.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsrNam.Location = New System.Drawing.Point(418, 207)
        Me.lblUsrNam.Name = "lblUsrNam"
        Me.lblUsrNam.Size = New System.Drawing.Size(164, 37)
        Me.lblUsrNam.TabIndex = 2
        Me.lblUsrNam.Text = "Username"
        '
        'lblPwd
        '
        Me.lblPwd.AutoSize = True
        Me.lblPwd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPwd.Location = New System.Drawing.Point(418, 317)
        Me.lblPwd.Name = "lblPwd"
        Me.lblPwd.Size = New System.Drawing.Size(158, 37)
        Me.lblPwd.TabIndex = 3
        Me.lblPwd.Text = "Password"
        '
        'txtUsrNam
        '
        Me.txtUsrNam.Location = New System.Drawing.Point(618, 217)
        Me.txtUsrNam.Name = "txtUsrNam"
        Me.txtUsrNam.Size = New System.Drawing.Size(194, 26)
        Me.txtUsrNam.TabIndex = 4
        '
        'txtPwd
        '
        Me.txtPwd.Location = New System.Drawing.Point(618, 327)
        Me.txtPwd.Name = "txtPwd"
        Me.txtPwd.Size = New System.Drawing.Size(194, 26)
        Me.txtPwd.TabIndex = 5
        '
        'btnRegs
        '
        Me.btnRegs.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegs.Location = New System.Drawing.Point(425, 418)
        Me.btnRegs.Name = "btnRegs"
        Me.btnRegs.Size = New System.Drawing.Size(156, 50)
        Me.btnRegs.TabIndex = 6
        Me.btnRegs.Text = "REGISTER"
        Me.btnRegs.UseVisualStyleBackColor = True
        '
        'btnLgn
        '
        Me.btnLgn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLgn.Location = New System.Drawing.Point(670, 418)
        Me.btnLgn.Name = "btnLgn"
        Me.btnLgn.Size = New System.Drawing.Size(175, 50)
        Me.btnLgn.TabIndex = 7
        Me.btnLgn.Text = "LOGIN"
        Me.btnLgn.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(773, 21)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 46)
        Me.btnCls.TabIndex = 8
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'Donor_Registration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(935, 572)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnLgn)
        Me.Controls.Add(Me.btnRegs)
        Me.Controls.Add(Me.txtPwd)
        Me.Controls.Add(Me.txtUsrNam)
        Me.Controls.Add(Me.lblPwd)
        Me.Controls.Add(Me.lblUsrNam)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblDnrReg)
        Me.Name = "Donor_Registration"
        Me.Text = "Donor_Registration"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDnrReg As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblUsrNam As Label
    Friend WithEvents lblPwd As Label
    Friend WithEvents txtUsrNam As TextBox
    Friend WithEvents txtPwd As TextBox
    Friend WithEvents btnRegs As Button
    Friend WithEvents btnLgn As Button
    Friend WithEvents btnCls As Button
End Class
