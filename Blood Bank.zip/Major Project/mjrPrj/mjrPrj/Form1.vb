﻿Imports System.Data.OleDb
Public Class Donor_Registration
    Dim cmd As OleDbCommand
    Private Sub Donor_Registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call pConnectDB()
    End Sub
    Private Sub btnRegs_Click(sender As Object, e As EventArgs) Handles btnRegs.Click
        Try
            Dim sSql As String
            sSql = "insert into tbDnrLgn values('" & txtUsrNam.Text & "','" & txtPwd.Text & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtUsrNam.Text = " "
            txtPwd.Text = " "
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dbcon.Close()
        End Try
    End Sub
    Private Sub Donor_Registration_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Call pDisconnectDB()
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
End Class