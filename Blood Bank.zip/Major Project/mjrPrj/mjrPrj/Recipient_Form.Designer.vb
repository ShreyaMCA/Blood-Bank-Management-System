﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Recipient_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblRecReg = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblUsrName = New System.Windows.Forms.Label()
        Me.lblPsd = New System.Windows.Forms.Label()
        Me.txtUsrName = New System.Windows.Forms.TextBox()
        Me.txtPsd = New System.Windows.Forms.TextBox()
        Me.btnReg = New System.Windows.Forms.Button()
        Me.btnLog = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblRecReg
        '
        Me.lblRecReg.AutoSize = True
        Me.lblRecReg.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecReg.Location = New System.Drawing.Point(12, 9)
        Me.lblRecReg.Name = "lblRecReg"
        Me.lblRecReg.Size = New System.Drawing.Size(321, 31)
        Me.lblRecReg.TabIndex = 1
        Me.lblRecReg.Text = "Recipient Registration"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.mjrPrj.My.Resources.Resources.login_img
        Me.PictureBox1.Location = New System.Drawing.Point(18, 166)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(320, 357)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'lblUsrName
        '
        Me.lblUsrName.AutoSize = True
        Me.lblUsrName.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsrName.Location = New System.Drawing.Point(391, 248)
        Me.lblUsrName.Name = "lblUsrName"
        Me.lblUsrName.Size = New System.Drawing.Size(164, 37)
        Me.lblUsrName.TabIndex = 3
        Me.lblUsrName.Text = "Username"
        '
        'lblPsd
        '
        Me.lblPsd.AutoSize = True
        Me.lblPsd.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPsd.Location = New System.Drawing.Point(397, 349)
        Me.lblPsd.Name = "lblPsd"
        Me.lblPsd.Size = New System.Drawing.Size(158, 37)
        Me.lblPsd.TabIndex = 4
        Me.lblPsd.Text = "Password"
        '
        'txtUsrName
        '
        Me.txtUsrName.Location = New System.Drawing.Point(577, 258)
        Me.txtUsrName.Name = "txtUsrName"
        Me.txtUsrName.Size = New System.Drawing.Size(194, 26)
        Me.txtUsrName.TabIndex = 5
        '
        'txtPsd
        '
        Me.txtPsd.Location = New System.Drawing.Point(577, 359)
        Me.txtPsd.Name = "txtPsd"
        Me.txtPsd.Size = New System.Drawing.Size(194, 26)
        Me.txtPsd.TabIndex = 6
        '
        'btnReg
        '
        Me.btnReg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReg.Location = New System.Drawing.Point(381, 446)
        Me.btnReg.Name = "btnReg"
        Me.btnReg.Size = New System.Drawing.Size(156, 50)
        Me.btnReg.TabIndex = 7
        Me.btnReg.Text = "REGISTER"
        Me.btnReg.UseVisualStyleBackColor = True
        '
        'btnLog
        '
        Me.btnLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLog.Location = New System.Drawing.Point(596, 446)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.Size = New System.Drawing.Size(175, 50)
        Me.btnLog.TabIndex = 8
        Me.btnLog.Text = "LOGIN"
        Me.btnLog.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(772, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 48)
        Me.btnCls.TabIndex = 9
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'Recipient_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(908, 616)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnLog)
        Me.Controls.Add(Me.btnReg)
        Me.Controls.Add(Me.txtPsd)
        Me.Controls.Add(Me.txtUsrName)
        Me.Controls.Add(Me.lblPsd)
        Me.Controls.Add(Me.lblUsrName)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblRecReg)
        Me.Name = "Recipient_Form"
        Me.Text = "Recipient_Form"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblRecReg As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblUsrName As Label
    Friend WithEvents lblPsd As Label
    Friend WithEvents txtUsrName As TextBox
    Friend WithEvents txtPsd As TextBox
    Friend WithEvents btnReg As Button
    Friend WithEvents btnLog As Button
    Friend WithEvents btnCls As Button
End Class
