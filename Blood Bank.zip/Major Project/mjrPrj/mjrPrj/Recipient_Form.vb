﻿Imports System.Data.OleDb
Public Class Recipient_Form
    Dim cmd As OleDbCommand
    Private Sub Recipient_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call pConnectDB()
    End Sub

    Private Sub btnReg_Click(sender As Object, e As EventArgs) Handles btnReg.Click
        Try
            Dim sSql As String
            sSql = "insert into tbRecLgn values('" & txtUsrName.Text & "','" & txtPsd.Text &  "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtUsrName.Text = " "
            txtPsd.Text = " "
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            dbcon.Close()
        End Try
    End Sub
    Private Sub Recipient_Form_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Call pDisconnectDB()
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
End Class