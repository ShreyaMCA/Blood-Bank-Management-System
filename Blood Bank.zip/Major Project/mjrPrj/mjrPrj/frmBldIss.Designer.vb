﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBldIss
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblBldIss = New System.Windows.Forms.Label()
        Me.lblRecNam = New System.Windows.Forms.Label()
        Me.lblBldTyp = New System.Windows.Forms.Label()
        Me.lblBldUnt = New System.Windows.Forms.Label()
        Me.txtRecNam = New System.Windows.Forms.TextBox()
        Me.TbBldIssBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbBldBnkSysDataSet12 = New mjrPrj.dbBldBnkSysDataSet12()
        Me.txtBldUnt = New System.Windows.Forms.TextBox()
        Me.cmbBldTyp = New System.Windows.Forms.ComboBox()
        Me.btnSub = New System.Windows.Forms.Button()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.btnEdt = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RecipientNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BloodTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BloodUnitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblRec = New System.Windows.Forms.Label()
        Me.TbBldIssTableAdapter = New mjrPrj.dbBldBnkSysDataSet12TableAdapters.tbBldIssTableAdapter()
        Me.cboRecLst = New System.Windows.Forms.ComboBox()
        Me.lblLst = New System.Windows.Forms.Label()
        CType(Me.TbBldIssBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbBldBnkSysDataSet12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblBldIss
        '
        Me.lblBldIss.AutoSize = True
        Me.lblBldIss.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldIss.Location = New System.Drawing.Point(27, 20)
        Me.lblBldIss.Name = "lblBldIss"
        Me.lblBldIss.Size = New System.Drawing.Size(167, 31)
        Me.lblBldIss.TabIndex = 2
        Me.lblBldIss.Text = "Blood Issue"
        '
        'lblRecNam
        '
        Me.lblRecNam.AutoSize = True
        Me.lblRecNam.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecNam.Location = New System.Drawing.Point(60, 230)
        Me.lblRecNam.Name = "lblRecNam"
        Me.lblRecNam.Size = New System.Drawing.Size(243, 37)
        Me.lblRecNam.TabIndex = 4
        Me.lblRecNam.Text = "Recipient Name"
        '
        'lblBldTyp
        '
        Me.lblBldTyp.AutoSize = True
        Me.lblBldTyp.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldTyp.Location = New System.Drawing.Point(71, 329)
        Me.lblBldTyp.Name = "lblBldTyp"
        Me.lblBldTyp.Size = New System.Drawing.Size(178, 37)
        Me.lblBldTyp.TabIndex = 5
        Me.lblBldTyp.Text = "Blood Type"
        '
        'lblBldUnt
        '
        Me.lblBldUnt.AutoSize = True
        Me.lblBldUnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldUnt.Location = New System.Drawing.Point(71, 437)
        Me.lblBldUnt.Name = "lblBldUnt"
        Me.lblBldUnt.Size = New System.Drawing.Size(165, 37)
        Me.lblBldUnt.TabIndex = 6
        Me.lblBldUnt.Text = "Blood Unit"
        '
        'txtRecNam
        '
        Me.txtRecNam.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbBldIssBindingSource, "Recipient_Name", True))
        Me.txtRecNam.Location = New System.Drawing.Point(401, 230)
        Me.txtRecNam.Name = "txtRecNam"
        Me.txtRecNam.Size = New System.Drawing.Size(161, 26)
        Me.txtRecNam.TabIndex = 7
        '
        'TbBldIssBindingSource
        '
        Me.TbBldIssBindingSource.DataMember = "tbBldIss"
        Me.TbBldIssBindingSource.DataSource = Me.DbBldBnkSysDataSet12
        '
        'DbBldBnkSysDataSet12
        '
        Me.DbBldBnkSysDataSet12.DataSetName = "dbBldBnkSysDataSet12"
        Me.DbBldBnkSysDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtBldUnt
        '
        Me.txtBldUnt.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbBldIssBindingSource, "Blood_Unit", True))
        Me.txtBldUnt.Location = New System.Drawing.Point(401, 447)
        Me.txtBldUnt.Name = "txtBldUnt"
        Me.txtBldUnt.Size = New System.Drawing.Size(161, 26)
        Me.txtBldUnt.TabIndex = 8
        '
        'cmbBldTyp
        '
        Me.cmbBldTyp.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbBldIssBindingSource, "Blood_Type", True))
        Me.cmbBldTyp.FormattingEnabled = True
        Me.cmbBldTyp.Items.AddRange(New Object() {"A+", "0+", "B+", "AB+", "A-", "O-", "B-", "AB-"})
        Me.cmbBldTyp.Location = New System.Drawing.Point(401, 339)
        Me.cmbBldTyp.Name = "cmbBldTyp"
        Me.cmbBldTyp.Size = New System.Drawing.Size(161, 28)
        Me.cmbBldTyp.TabIndex = 9
        '
        'btnSub
        '
        Me.btnSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSub.Location = New System.Drawing.Point(12, 540)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(152, 53)
        Me.btnSub.TabIndex = 10
        Me.btnSub.Text = "SUBMIT"
        Me.btnSub.UseVisualStyleBackColor = True
        '
        'btnDel
        '
        Me.btnDel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDel.Location = New System.Drawing.Point(401, 540)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(169, 53)
        Me.btnDel.TabIndex = 12
        Me.btnDel.Text = "DELETE"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'btnEdt
        '
        Me.btnEdt.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdt.Location = New System.Drawing.Point(203, 540)
        Me.btnEdt.Name = "btnEdt"
        Me.btnEdt.Size = New System.Drawing.Size(158, 53)
        Me.btnEdt.TabIndex = 11
        Me.btnEdt.Text = "EDIT"
        Me.btnEdt.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(1177, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 46)
        Me.btnCls.TabIndex = 13
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RecipientNameDataGridViewTextBoxColumn, Me.BloodTypeDataGridViewTextBoxColumn, Me.BloodUnitDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TbBldIssBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(621, 143)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(715, 438)
        Me.DataGridView1.TabIndex = 14
        '
        'RecipientNameDataGridViewTextBoxColumn
        '
        Me.RecipientNameDataGridViewTextBoxColumn.DataPropertyName = "Recipient_Name"
        Me.RecipientNameDataGridViewTextBoxColumn.HeaderText = "Recipient_Name"
        Me.RecipientNameDataGridViewTextBoxColumn.Name = "RecipientNameDataGridViewTextBoxColumn"
        '
        'BloodTypeDataGridViewTextBoxColumn
        '
        Me.BloodTypeDataGridViewTextBoxColumn.DataPropertyName = "Blood_Type"
        Me.BloodTypeDataGridViewTextBoxColumn.HeaderText = "Blood_Type"
        Me.BloodTypeDataGridViewTextBoxColumn.Name = "BloodTypeDataGridViewTextBoxColumn"
        '
        'BloodUnitDataGridViewTextBoxColumn
        '
        Me.BloodUnitDataGridViewTextBoxColumn.DataPropertyName = "Blood_Unit"
        Me.BloodUnitDataGridViewTextBoxColumn.HeaderText = "Blood_Unit"
        Me.BloodUnitDataGridViewTextBoxColumn.Name = "BloodUnitDataGridViewTextBoxColumn"
        '
        'lblRec
        '
        Me.lblRec.AutoSize = True
        Me.lblRec.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRec.Location = New System.Drawing.Point(863, 84)
        Me.lblRec.Name = "lblRec"
        Me.lblRec.Size = New System.Drawing.Size(150, 46)
        Me.lblRec.TabIndex = 15
        Me.lblRec.Text = "Record"
        '
        'TbBldIssTableAdapter
        '
        Me.TbBldIssTableAdapter.ClearBeforeFill = True
        '
        'cboRecLst
        '
        Me.cboRecLst.FormattingEnabled = True
        Me.cboRecLst.Location = New System.Drawing.Point(344, 134)
        Me.cboRecLst.Name = "cboRecLst"
        Me.cboRecLst.Size = New System.Drawing.Size(199, 28)
        Me.cboRecLst.TabIndex = 16
        '
        'lblLst
        '
        Me.lblLst.AutoSize = True
        Me.lblLst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLst.Location = New System.Drawing.Point(96, 125)
        Me.lblLst.Name = "lblLst"
        Me.lblLst.Size = New System.Drawing.Size(207, 37)
        Me.lblLst.TabIndex = 17
        Me.lblLst.Text = "Recipient List"
        '
        'frmBldIss
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1379, 631)
        Me.Controls.Add(Me.lblLst)
        Me.Controls.Add(Me.cboRecLst)
        Me.Controls.Add(Me.lblRec)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.btnEdt)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.cmbBldTyp)
        Me.Controls.Add(Me.txtBldUnt)
        Me.Controls.Add(Me.txtRecNam)
        Me.Controls.Add(Me.lblBldUnt)
        Me.Controls.Add(Me.lblBldTyp)
        Me.Controls.Add(Me.lblRecNam)
        Me.Controls.Add(Me.lblBldIss)
        Me.Name = "frmBldIss"
        Me.Text = "frmBldIss"
        CType(Me.TbBldIssBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbBldBnkSysDataSet12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBldIss As Label
    Friend WithEvents lblRecNam As Label
    Friend WithEvents lblBldTyp As Label
    Friend WithEvents lblBldUnt As Label
    Friend WithEvents txtRecNam As TextBox
    Friend WithEvents txtBldUnt As TextBox
    Friend WithEvents cmbBldTyp As ComboBox
    Friend WithEvents btnSub As Button
    Friend WithEvents btnDel As Button
    Friend WithEvents btnEdt As Button
    Friend WithEvents btnCls As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblRec As Label
    Friend WithEvents DbBldBnkSysDataSet12 As dbBldBnkSysDataSet12
    Friend WithEvents TbBldIssBindingSource As BindingSource
    Friend WithEvents TbBldIssTableAdapter As dbBldBnkSysDataSet12TableAdapters.tbBldIssTableAdapter
    Friend WithEvents RecipientNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BloodTypeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BloodUnitDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents cboRecLst As ComboBox
    Friend WithEvents lblLst As Label
End Class
