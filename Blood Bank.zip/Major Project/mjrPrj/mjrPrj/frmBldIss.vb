﻿Imports System.Data.OleDb
Public Class frmBldIss
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub frmBldIss_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet12.tbBldIss' table. You can move, or remove it, as needed.
        Me.TbBldIssTableAdapter.Fill(Me.DbBldBnkSysDataSet12.tbBldIss)
        Call pConnectDB()
        Call pcboRec()
    End Sub

    Private Sub btnSub_Click(sender As Object, e As EventArgs) Handles btnSub.Click
        Try
            Dim sSql As String
            sSql = "insert into tbBldIss values('" & txtRecNam.Text & "','" & cmbBldTyp.Text & "','" & txtBldUnt.Text & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtRecNam.Text = " "
            cmbBldTyp.Text = " "
            txtBldUnt.Text = " "
            MessageBox.Show(cmbBldTyp.SelectedItem & "is selected")
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        Try
            Dim sSql As String
            sSql = "delete * from tbBldIss where Recipient_Name = '" & txtRecNam.Text & "'"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtRecNam.Text = " "
            cmbBldTyp.Text = " "
            txtBldUnt.Text = " "
            MessageBox.Show(cmbBldTyp.SelectedItem & "is deleted")
            MsgBox("Record has been deleted!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnEdt_Click(sender As Object, e As EventArgs) Handles btnEdt.Click
        Try
            Dim sSql As String
            sSql = "update tbBldIss set Blood_Unit = '" & txtBldUnt.Text & "'," & "Blood_Type = " & cmbBldTyp.Text & " where Recipient_Name = " & txtRecNam.Text
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtRecNam.Text = " "
            cmbBldTyp.Text = " "
            txtBldUnt.Text = " "
            MessageBox.Show(cmbBldTyp.SelectedItem & "is Updated")
            MsgBox("Record has been updated!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub

    Private Sub cboRecLst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRecLst.SelectedIndexChanged
        Dim sSql As String
        sSql = "select * from tbBldIss where Recipient_Name = '" & cboRecLst.Text & "'"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        dr.Read()
        txtRecNam.Text = dr.Item("Recipient_Name")
        cmbBldTyp.Text = dr.Item("Blood_Type")
        txtBldUnt.Text = dr.Item("Blood_Unit")
    End Sub
    Private Sub pcboRec()
        cboRecLst.Items.Clear()
        Dim sSql As String
        sSql = "select * from tbBldIss"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboRecLst.Items.Add(dr.Item("Recipient_Name"))
            'MessageBox.Show(dr.Item("empNam"))
        End While
        cboRecLst.SelectedIndex = 0
    End Sub
End Class