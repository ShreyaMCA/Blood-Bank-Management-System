﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCmp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblCmp = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblVnu = New System.Windows.Forms.Label()
        Me.lblCty = New System.Windows.Forms.Label()
        Me.lblOrg = New System.Windows.Forms.Label()
        Me.txtId = New System.Windows.Forms.TextBox()
        Me.TbCmpBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbBldBnkSysDataSet11 = New mjrPrj.dbBldBnkSysDataSet11()
        Me.txtVnu = New System.Windows.Forms.TextBox()
        Me.txtCty = New System.Windows.Forms.TextBox()
        Me.txtOrg = New System.Windows.Forms.TextBox()
        Me.btnCmpSub = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.lblCmpDte = New System.Windows.Forms.Label()
        Me.dteTmePkr = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VenueDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrganizerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CampDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TbCmpTableAdapter = New mjrPrj.dbBldBnkSysDataSet11TableAdapters.tbCmpTableAdapter()
        Me.lblCmpLst = New System.Windows.Forms.Label()
        Me.cboCmpLst = New System.Windows.Forms.ComboBox()
        CType(Me.TbCmpBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbBldBnkSysDataSet11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblCmp
        '
        Me.lblCmp.AutoSize = True
        Me.lblCmp.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCmp.Location = New System.Drawing.Point(26, 20)
        Me.lblCmp.Name = "lblCmp"
        Me.lblCmp.Size = New System.Drawing.Size(91, 31)
        Me.lblCmp.TabIndex = 3
        Me.lblCmp.Text = "Camp"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(138, 161)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(48, 37)
        Me.lblID.TabIndex = 5
        Me.lblID.Text = "ID"
        '
        'lblVnu
        '
        Me.lblVnu.AutoSize = True
        Me.lblVnu.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVnu.Location = New System.Drawing.Point(138, 226)
        Me.lblVnu.Name = "lblVnu"
        Me.lblVnu.Size = New System.Drawing.Size(109, 37)
        Me.lblVnu.TabIndex = 7
        Me.lblVnu.Text = "Venue"
        '
        'lblCty
        '
        Me.lblCty.AutoSize = True
        Me.lblCty.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCty.Location = New System.Drawing.Point(138, 308)
        Me.lblCty.Name = "lblCty"
        Me.lblCty.Size = New System.Drawing.Size(71, 37)
        Me.lblCty.TabIndex = 8
        Me.lblCty.Text = "City"
        '
        'lblOrg
        '
        Me.lblOrg.AutoSize = True
        Me.lblOrg.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrg.Location = New System.Drawing.Point(138, 385)
        Me.lblOrg.Name = "lblOrg"
        Me.lblOrg.Size = New System.Drawing.Size(158, 37)
        Me.lblOrg.TabIndex = 9
        Me.lblOrg.Text = "Organizer"
        '
        'txtId
        '
        Me.txtId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbCmpBindingSource, "ID", True))
        Me.txtId.Location = New System.Drawing.Point(377, 161)
        Me.txtId.Name = "txtId"
        Me.txtId.Size = New System.Drawing.Size(161, 26)
        Me.txtId.TabIndex = 10
        '
        'TbCmpBindingSource
        '
        Me.TbCmpBindingSource.DataMember = "tbCmp"
        Me.TbCmpBindingSource.DataSource = Me.DbBldBnkSysDataSet11
        '
        'DbBldBnkSysDataSet11
        '
        Me.DbBldBnkSysDataSet11.DataSetName = "dbBldBnkSysDataSet11"
        Me.DbBldBnkSysDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtVnu
        '
        Me.txtVnu.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbCmpBindingSource, "Venue", True))
        Me.txtVnu.Location = New System.Drawing.Point(377, 226)
        Me.txtVnu.Name = "txtVnu"
        Me.txtVnu.Size = New System.Drawing.Size(161, 26)
        Me.txtVnu.TabIndex = 11
        '
        'txtCty
        '
        Me.txtCty.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbCmpBindingSource, "City", True))
        Me.txtCty.Location = New System.Drawing.Point(377, 308)
        Me.txtCty.Name = "txtCty"
        Me.txtCty.Size = New System.Drawing.Size(161, 26)
        Me.txtCty.TabIndex = 12
        '
        'txtOrg
        '
        Me.txtOrg.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbCmpBindingSource, "Organizer", True))
        Me.txtOrg.Location = New System.Drawing.Point(377, 385)
        Me.txtOrg.Name = "txtOrg"
        Me.txtOrg.Size = New System.Drawing.Size(161, 26)
        Me.txtOrg.TabIndex = 13
        '
        'btnCmpSub
        '
        Me.btnCmpSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCmpSub.Location = New System.Drawing.Point(255, 534)
        Me.btnCmpSub.Name = "btnCmpSub"
        Me.btnCmpSub.Size = New System.Drawing.Size(152, 53)
        Me.btnCmpSub.TabIndex = 15
        Me.btnCmpSub.Text = "SUBMIT"
        Me.btnCmpSub.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(1392, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 47)
        Me.btnCls.TabIndex = 16
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'lblCmpDte
        '
        Me.lblCmpDte.AutoSize = True
        Me.lblCmpDte.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCmpDte.Location = New System.Drawing.Point(138, 454)
        Me.lblCmpDte.Name = "lblCmpDte"
        Me.lblCmpDte.Size = New System.Drawing.Size(179, 37)
        Me.lblCmpDte.TabIndex = 41
        Me.lblCmpDte.Text = "Camp Date"
        '
        'dteTmePkr
        '
        Me.dteTmePkr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbCmpBindingSource, "Camp Date", True))
        Me.dteTmePkr.Location = New System.Drawing.Point(377, 465)
        Me.dteTmePkr.Name = "dteTmePkr"
        Me.dteTmePkr.Size = New System.Drawing.Size(196, 26)
        Me.dteTmePkr.TabIndex = 42
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(926, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(239, 40)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Camp Record"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.VenueDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.OrganizerDataGridViewTextBoxColumn, Me.CampDateDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TbCmpBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(628, 126)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(871, 439)
        Me.DataGridView1.TabIndex = 44
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'VenueDataGridViewTextBoxColumn
        '
        Me.VenueDataGridViewTextBoxColumn.DataPropertyName = "Venue"
        Me.VenueDataGridViewTextBoxColumn.HeaderText = "Venue"
        Me.VenueDataGridViewTextBoxColumn.Name = "VenueDataGridViewTextBoxColumn"
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "City"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "City"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        '
        'OrganizerDataGridViewTextBoxColumn
        '
        Me.OrganizerDataGridViewTextBoxColumn.DataPropertyName = "Organizer"
        Me.OrganizerDataGridViewTextBoxColumn.HeaderText = "Organizer"
        Me.OrganizerDataGridViewTextBoxColumn.Name = "OrganizerDataGridViewTextBoxColumn"
        '
        'CampDateDataGridViewTextBoxColumn
        '
        Me.CampDateDataGridViewTextBoxColumn.DataPropertyName = "Camp Date"
        Me.CampDateDataGridViewTextBoxColumn.HeaderText = "Camp Date"
        Me.CampDateDataGridViewTextBoxColumn.Name = "CampDateDataGridViewTextBoxColumn"
        '
        'TbCmpTableAdapter
        '
        Me.TbCmpTableAdapter.ClearBeforeFill = True
        '
        'lblCmpLst
        '
        Me.lblCmpLst.AutoSize = True
        Me.lblCmpLst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCmpLst.Location = New System.Drawing.Point(89, 79)
        Me.lblCmpLst.Name = "lblCmpLst"
        Me.lblCmpLst.Size = New System.Drawing.Size(162, 37)
        Me.lblCmpLst.TabIndex = 45
        Me.lblCmpLst.Text = "Camp List"
        '
        'cboCmpLst
        '
        Me.cboCmpLst.FormattingEnabled = True
        Me.cboCmpLst.Location = New System.Drawing.Point(374, 79)
        Me.cboCmpLst.Name = "cboCmpLst"
        Me.cboCmpLst.Size = New System.Drawing.Size(164, 28)
        Me.cboCmpLst.TabIndex = 46
        '
        'frmCmp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1528, 653)
        Me.Controls.Add(Me.cboCmpLst)
        Me.Controls.Add(Me.lblCmpLst)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dteTmePkr)
        Me.Controls.Add(Me.lblCmpDte)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnCmpSub)
        Me.Controls.Add(Me.txtOrg)
        Me.Controls.Add(Me.txtCty)
        Me.Controls.Add(Me.txtVnu)
        Me.Controls.Add(Me.txtId)
        Me.Controls.Add(Me.lblOrg)
        Me.Controls.Add(Me.lblCty)
        Me.Controls.Add(Me.lblVnu)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.lblCmp)
        Me.Name = "frmCmp"
        Me.Text = "frmCmp"
        CType(Me.TbCmpBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbBldBnkSysDataSet11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCmp As Label
    Friend WithEvents lblID As Label
    Friend WithEvents lblVnu As Label
    Friend WithEvents lblCty As Label
    Friend WithEvents lblOrg As Label
    Friend WithEvents txtId As TextBox
    Friend WithEvents txtVnu As TextBox
    Friend WithEvents txtCty As TextBox
    Friend WithEvents txtOrg As TextBox
    Friend WithEvents btnCmpSub As Button
    Friend WithEvents btnCls As Button
    Friend WithEvents lblCmpDte As Label
    Friend WithEvents dteTmePkr As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DbBldBnkSysDataSet11 As dbBldBnkSysDataSet11
    Friend WithEvents TbCmpBindingSource As BindingSource
    Friend WithEvents TbCmpTableAdapter As dbBldBnkSysDataSet11TableAdapters.tbCmpTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VenueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OrganizerDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CampDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents lblCmpLst As Label
    Friend WithEvents cboCmpLst As ComboBox
End Class
