﻿Imports System.Data.OleDb
Public Class frmCmp
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub frmCmp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet11.tbCmp' table. You can move, or remove it, as needed.
        Me.TbCmpTableAdapter.Fill(Me.DbBldBnkSysDataSet11.tbCmp)
        Call pConnectDB()
        Call pcboCmp()
    End Sub

    Private Sub btnCmpSub_Click(sender As Object, e As EventArgs) Handles btnCmpSub.Click
        Try
            Dim sSql As String
            Dim Date11 As String = Format(dteTmePkr.Value, "dd-MM-yyyy")
            sSql = "insert into tbCmp values('" & txtId.Text & "','" & txtVnu.Text & "','" & txtCty.Text & "','" & txtOrg.Text & "','" & Date11 & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtId.Text = " "
            txtVnu.Text = " "
            txtCty.Text = " "
            txtOrg.Text = " "
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
    Private Sub cboCmpLst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCmpLst.SelectedIndexChanged
        Dim sSql As String
        sSql = "select * from tbCmp where Venue = '" & txtVnu.Text & "'"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        dr.Read()
        txtId.Text = dr.Item("ID")
        txtVnu.Text = dr.Item("Venue")
        txtCty.Text = dr.Item("City")
        txtOrg.Text = dr.Item("Organizer")
        dteTmePkr.Text = dr.Item("Camp Date")
    End Sub
    Private Sub pcboCmp()
        cboCmpLst.Items.Clear()
        Dim sSql As String
        sSql = "select * from tbCmp"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboCmpLst.Items.Add(dr.Item("Venue"))
            'MessageBox.Show(dr.Item("empNam"))
        End While
        cboCmpLst.SelectedIndex = 0
    End Sub
End Class