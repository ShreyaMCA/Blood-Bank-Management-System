﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDnr
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDnr = New System.Windows.Forms.Label()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblNam = New System.Windows.Forms.Label()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.lblAdr = New System.Windows.Forms.Label()
        Me.lblCntNum = New System.Windows.Forms.Label()
        Me.lblBldType = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.TbDnrBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbBldBnkSysDataSet9 = New mjrPrj.dbBldBnkSysDataSet9()
        Me.txtNam = New System.Windows.Forms.TextBox()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.txtAdr = New System.Windows.Forms.TextBox()
        Me.txtCntNum = New System.Windows.Forms.TextBox()
        Me.cmbBldType = New System.Windows.Forms.ComboBox()
        Me.btnSub = New System.Windows.Forms.Button()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.lblDteDnt = New System.Windows.Forms.Label()
        Me.dteTmePik = New System.Windows.Forms.DateTimePicker()
        Me.lblRcd = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AgeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddresDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateOfDonationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TbDnrTableAdapter = New mjrPrj.dbBldBnkSysDataSet9TableAdapters.tbDnrTableAdapter()
        Me.lblDnrLst = New System.Windows.Forms.Label()
        Me.cboDnrLst = New System.Windows.Forms.ComboBox()
        CType(Me.TbDnrBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbBldBnkSysDataSet9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDnr
        '
        Me.lblDnr.AutoSize = True
        Me.lblDnr.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDnr.Location = New System.Drawing.Point(12, 12)
        Me.lblDnr.Name = "lblDnr"
        Me.lblDnr.Size = New System.Drawing.Size(99, 31)
        Me.lblDnr.TabIndex = 3
        Me.lblDnr.Text = "Donor"
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(1390, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 46)
        Me.btnCls.TabIndex = 14
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(131, 121)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(48, 37)
        Me.lblID.TabIndex = 15
        Me.lblID.Text = "ID"
        '
        'lblNam
        '
        Me.lblNam.AutoSize = True
        Me.lblNam.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNam.Location = New System.Drawing.Point(116, 192)
        Me.lblNam.Name = "lblNam"
        Me.lblNam.Size = New System.Drawing.Size(112, 37)
        Me.lblNam.TabIndex = 16
        Me.lblNam.Text = " Name"
        '
        'lblAge
        '
        Me.lblAge.AutoSize = True
        Me.lblAge.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAge.Location = New System.Drawing.Point(131, 277)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(74, 37)
        Me.lblAge.TabIndex = 17
        Me.lblAge.Text = "Age"
        '
        'lblAdr
        '
        Me.lblAdr.AutoSize = True
        Me.lblAdr.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdr.Location = New System.Drawing.Point(116, 352)
        Me.lblAdr.Name = "lblAdr"
        Me.lblAdr.Size = New System.Drawing.Size(135, 37)
        Me.lblAdr.TabIndex = 18
        Me.lblAdr.Text = "Address"
        '
        'lblCntNum
        '
        Me.lblCntNum.AutoSize = True
        Me.lblCntNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCntNum.Location = New System.Drawing.Point(71, 417)
        Me.lblCntNum.Name = "lblCntNum"
        Me.lblCntNum.Size = New System.Drawing.Size(252, 37)
        Me.lblCntNum.TabIndex = 20
        Me.lblCntNum.Text = "Contact Number"
        '
        'lblBldType
        '
        Me.lblBldType.AutoSize = True
        Me.lblBldType.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldType.Location = New System.Drawing.Point(116, 473)
        Me.lblBldType.Name = "lblBldType"
        Me.lblBldType.Size = New System.Drawing.Size(178, 37)
        Me.lblBldType.TabIndex = 21
        Me.lblBldType.Text = "Blood Type"
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "ID", True))
        Me.txtID.Location = New System.Drawing.Point(399, 121)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(161, 26)
        Me.txtID.TabIndex = 22
        '
        'TbDnrBindingSource
        '
        Me.TbDnrBindingSource.DataMember = "tbDnr"
        Me.TbDnrBindingSource.DataSource = Me.DbBldBnkSysDataSet9
        '
        'DbBldBnkSysDataSet9
        '
        Me.DbBldBnkSysDataSet9.DataSetName = "dbBldBnkSysDataSet9"
        Me.DbBldBnkSysDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtNam
        '
        Me.txtNam.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "Name", True))
        Me.txtNam.Location = New System.Drawing.Point(399, 192)
        Me.txtNam.Name = "txtNam"
        Me.txtNam.Size = New System.Drawing.Size(161, 26)
        Me.txtNam.TabIndex = 23
        '
        'txtAge
        '
        Me.txtAge.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "Age", True))
        Me.txtAge.Location = New System.Drawing.Point(399, 268)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(161, 26)
        Me.txtAge.TabIndex = 24
        '
        'txtAdr
        '
        Me.txtAdr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "Addres", True))
        Me.txtAdr.Location = New System.Drawing.Point(399, 343)
        Me.txtAdr.Name = "txtAdr"
        Me.txtAdr.Size = New System.Drawing.Size(161, 26)
        Me.txtAdr.TabIndex = 25
        '
        'txtCntNum
        '
        Me.txtCntNum.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "Contact Number", True))
        Me.txtCntNum.Location = New System.Drawing.Point(399, 403)
        Me.txtCntNum.Name = "txtCntNum"
        Me.txtCntNum.Size = New System.Drawing.Size(161, 26)
        Me.txtCntNum.TabIndex = 26
        '
        'cmbBldType
        '
        Me.cmbBldType.FormattingEnabled = True
        Me.cmbBldType.Items.AddRange(New Object() {"A+", "0+", "B+", "AB+", "A-", "O-", "B-", "AB-"})
        Me.cmbBldType.Location = New System.Drawing.Point(399, 473)
        Me.cmbBldType.Name = "cmbBldType"
        Me.cmbBldType.Size = New System.Drawing.Size(161, 28)
        Me.cmbBldType.TabIndex = 27
        '
        'btnSub
        '
        Me.btnSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSub.Location = New System.Drawing.Point(99, 610)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(152, 53)
        Me.btnSub.TabIndex = 30
        Me.btnSub.Text = "SUBMIT"
        Me.btnSub.UseVisualStyleBackColor = True
        '
        'btnDel
        '
        Me.btnDel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDel.Location = New System.Drawing.Point(399, 610)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(169, 53)
        Me.btnDel.TabIndex = 32
        Me.btnDel.Text = "DELETE"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'lblDteDnt
        '
        Me.lblDteDnt.AutoSize = True
        Me.lblDteDnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDteDnt.Location = New System.Drawing.Point(65, 536)
        Me.lblDteDnt.Name = "lblDteDnt"
        Me.lblDteDnt.Size = New System.Drawing.Size(258, 37)
        Me.lblDteDnt.TabIndex = 33
        Me.lblDteDnt.Text = "Date of Donation"
        '
        'dteTmePik
        '
        Me.dteTmePik.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbDnrBindingSource, "Date of Donation", True))
        Me.dteTmePik.Location = New System.Drawing.Point(399, 536)
        Me.dteTmePik.Name = "dteTmePik"
        Me.dteTmePik.Size = New System.Drawing.Size(196, 26)
        Me.dteTmePik.TabIndex = 34
        '
        'lblRcd
        '
        Me.lblRcd.AutoSize = True
        Me.lblRcd.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRcd.Location = New System.Drawing.Point(922, 86)
        Me.lblRcd.Name = "lblRcd"
        Me.lblRcd.Size = New System.Drawing.Size(271, 46)
        Me.lblRcd.TabIndex = 35
        Me.lblRcd.Text = "Donor Record"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn, Me.AgeDataGridViewTextBoxColumn, Me.AddresDataGridViewTextBoxColumn, Me.ContactNumberDataGridViewTextBoxColumn, Me.DateOfDonationDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TbDnrBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(601, 157)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(927, 416)
        Me.DataGridView1.TabIndex = 36
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'AgeDataGridViewTextBoxColumn
        '
        Me.AgeDataGridViewTextBoxColumn.DataPropertyName = "Age"
        Me.AgeDataGridViewTextBoxColumn.HeaderText = "Age"
        Me.AgeDataGridViewTextBoxColumn.Name = "AgeDataGridViewTextBoxColumn"
        '
        'AddresDataGridViewTextBoxColumn
        '
        Me.AddresDataGridViewTextBoxColumn.DataPropertyName = "Addres"
        Me.AddresDataGridViewTextBoxColumn.HeaderText = "Addres"
        Me.AddresDataGridViewTextBoxColumn.Name = "AddresDataGridViewTextBoxColumn"
        '
        'ContactNumberDataGridViewTextBoxColumn
        '
        Me.ContactNumberDataGridViewTextBoxColumn.DataPropertyName = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.HeaderText = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.Name = "ContactNumberDataGridViewTextBoxColumn"
        '
        'DateOfDonationDataGridViewTextBoxColumn
        '
        Me.DateOfDonationDataGridViewTextBoxColumn.DataPropertyName = "Date of Donation"
        Me.DateOfDonationDataGridViewTextBoxColumn.HeaderText = "Date of Donation"
        Me.DateOfDonationDataGridViewTextBoxColumn.Name = "DateOfDonationDataGridViewTextBoxColumn"
        '
        'TbDnrTableAdapter
        '
        Me.TbDnrTableAdapter.ClearBeforeFill = True
        '
        'lblDnrLst
        '
        Me.lblDnrLst.AutoSize = True
        Me.lblDnrLst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDnrLst.Location = New System.Drawing.Point(116, 64)
        Me.lblDnrLst.Name = "lblDnrLst"
        Me.lblDnrLst.Size = New System.Drawing.Size(164, 37)
        Me.lblDnrLst.TabIndex = 46
        Me.lblDnrLst.Text = "Donor List"
        '
        'cboDnrLst
        '
        Me.cboDnrLst.FormattingEnabled = True
        Me.cboDnrLst.Location = New System.Drawing.Point(396, 64)
        Me.cboDnrLst.Name = "cboDnrLst"
        Me.cboDnrLst.Size = New System.Drawing.Size(164, 28)
        Me.cboDnrLst.TabIndex = 47
        '
        'frmDnr
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1540, 676)
        Me.Controls.Add(Me.cboDnrLst)
        Me.Controls.Add(Me.lblDnrLst)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblRcd)
        Me.Controls.Add(Me.dteTmePik)
        Me.Controls.Add(Me.lblDteDnt)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.cmbBldType)
        Me.Controls.Add(Me.txtCntNum)
        Me.Controls.Add(Me.txtAdr)
        Me.Controls.Add(Me.txtAge)
        Me.Controls.Add(Me.txtNam)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblBldType)
        Me.Controls.Add(Me.lblCntNum)
        Me.Controls.Add(Me.lblAdr)
        Me.Controls.Add(Me.lblAge)
        Me.Controls.Add(Me.lblNam)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.lblDnr)
        Me.Name = "frmDnr"
        Me.Text = "frmDnr"
        CType(Me.TbDnrBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbBldBnkSysDataSet9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDnr As Label
    Friend WithEvents btnCls As Button
    Friend WithEvents lblID As Label
    Friend WithEvents lblNam As Label
    Friend WithEvents lblAge As Label
    Friend WithEvents lblAdr As Label
    Friend WithEvents lblCntNum As Label
    Friend WithEvents lblBldType As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtNam As TextBox
    Friend WithEvents txtAge As TextBox
    Friend WithEvents txtAdr As TextBox
    Friend WithEvents txtCntNum As TextBox
    Friend WithEvents cmbBldType As ComboBox
    Friend WithEvents btnSub As Button
    Friend WithEvents btnDel As Button
    Friend WithEvents lblDteDnt As Label
    Friend WithEvents dteTmePik As DateTimePicker
    Friend WithEvents lblRcd As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DbBldBnkSysDataSet9 As dbBldBnkSysDataSet9
    Friend WithEvents TbDnrBindingSource As BindingSource
    Friend WithEvents TbDnrTableAdapter As dbBldBnkSysDataSet9TableAdapters.tbDnrTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AgeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddresDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ContactNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateOfDonationDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents lblDnrLst As Label
    Friend WithEvents cboDnrLst As ComboBox
End Class
