﻿Imports System.Data.OleDb
Public Class frmDnr
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub frmDnr_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet9.tbDnr' table. You can move, or remove it, as needed.
        Me.TbDnrTableAdapter.Fill(Me.DbBldBnkSysDataSet9.tbDnr)
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet7.tbDnr' table. You can move, or remove it, as needed.
        Me.TbDnrTableAdapter.Fill(Me.DbBldBnkSysDataSet9.tbDnr)
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet6.tbDnr' table. You can move, or remove it, as needed.
        Me.TbDnrTableAdapter.Fill(Me.DbBldBnkSysDataSet9.tbDnr)
        Call pConnectDB()
        Call pcboDnr()
    End Sub

    Private Sub btnSub_Click(sender As Object, e As EventArgs) Handles btnSub.Click
        Try
            Dim sSql As String
            Dim Date11 As String = Format(dteTmePik.Value, "dd-MM-yyyy")
            sSql = "insert into tbDnr values('" & txtID.Text & "','" & txtNam.Text & "','" & txtAge.Text & "','" & txtAdr.Text & "','" & txtCntNum.Text & "','" & cmbBldType.Text & "','" & Date11 & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtID.Text = " "
            txtNam.Text = " "
            txtAge.Text = " "
            txtAdr.Text = " "
            txtCntNum.Text = " "
            cmbBldType.Text = " "
            MessageBox.Show(cmbBldType.SelectedItem & "is selected")
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub

    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        Try
            Dim sSql As String
            sSql = "delete * from tbDnr where Name = '" & txtNam.Text & "'"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtID.Text = " "
            txtNam.Text = " "
            txtAge.Text = " "
            txtAdr.Text = " "
            txtCntNum.Text = " "
            cmbBldType.Text = " "
            MessageBox.Show(cmbBldType.SelectedItem & "is deleted")
            MsgBox("Record is deleted!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub
    Private Sub cboDnrLst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDnrLst.SelectedIndexChanged
        Dim sSql As String
        sSql = "select * from tbDnr where Name = '" & txtNam.Text & "'"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        dr.Read()
        txtID.Text = dr.Item("ID")
        txtNam.Text = dr.Item("Name")
        txtAge.Text = dr.Item("Age")
        txtAdr.Text = dr.Item("Addres")
        txtCntNum.Text = dr.Item("Contact Number")
        cmbBldType.Text = dr.Item("Blood_Type")
        dteTmePik.Text = dr.Item("Date of Donation")
    End Sub
    Private Sub pcboDnr()
        cboDnrLst.Items.Clear()
        Dim sSql As String
        sSql = "select * from tbDnr"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboDnrLst.Items.Add(dr.Item("Name"))
            'MessageBox.Show(dr.Item("empNam"))
        End While
        cboDnrLst.SelectedIndex = 0
    End Sub
End Class