﻿Imports System.Data.OleDb
Public Class frmLog
    Dim cmd As OleDbCommand
    Private Sub frmLog_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call pConnectDB()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Trim(UsernameTextBox.Text) = "" Or Trim(PasswordTextBox.Text) = "" Then
            MsgBox("Please Enter Both Fields!", vbInformation, "Note")
        Else
            Dim sql = "SELECT * FROM tbluser WHERE username = '" & UsernameTextBox.Text & "' AND password = '" & PasswordTextBox.Text & "'"
            Dim cmd = New OleDbCommand(sql, dbcon)
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            Try
                If dr.Read = False Then
                    MsgBox("Login Failed!", vbCritical, "Note")
                Else
                    MsgBox("Login Successful!", vbInformation, "Note")
                    'Me.Hide()
                    frmRegs.Show()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            'con.Close()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub
End Class