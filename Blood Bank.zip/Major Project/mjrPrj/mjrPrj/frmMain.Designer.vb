﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DonorRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecipientRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DonorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecipientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BloodIssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CampToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QueriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Report1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Report2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Report3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Report4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DonorRegistrationToolStripMenuItem, Me.RecipientRegistrationToolStripMenuItem, Me.DonorToolStripMenuItem, Me.RecipientToolStripMenuItem, Me.BloodIssueToolStripMenuItem, Me.StockToolStripMenuItem, Me.CampToolStripMenuItem, Me.QueriesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1521, 46)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DonorRegistrationToolStripMenuItem
        '
        Me.DonorRegistrationToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DonorRegistrationToolStripMenuItem.Name = "DonorRegistrationToolStripMenuItem"
        Me.DonorRegistrationToolStripMenuItem.Size = New System.Drawing.Size(262, 42)
        Me.DonorRegistrationToolStripMenuItem.Text = "Donor Registration"
        '
        'RecipientRegistrationToolStripMenuItem
        '
        Me.RecipientRegistrationToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RecipientRegistrationToolStripMenuItem.Name = "RecipientRegistrationToolStripMenuItem"
        Me.RecipientRegistrationToolStripMenuItem.Size = New System.Drawing.Size(298, 42)
        Me.RecipientRegistrationToolStripMenuItem.Text = "Recipient Registration"
        '
        'DonorToolStripMenuItem
        '
        Me.DonorToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DonorToolStripMenuItem.Name = "DonorToolStripMenuItem"
        Me.DonorToolStripMenuItem.Size = New System.Drawing.Size(107, 42)
        Me.DonorToolStripMenuItem.Text = "Donor"
        '
        'RecipientToolStripMenuItem
        '
        Me.RecipientToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RecipientToolStripMenuItem.Name = "RecipientToolStripMenuItem"
        Me.RecipientToolStripMenuItem.Size = New System.Drawing.Size(143, 42)
        Me.RecipientToolStripMenuItem.Text = "Recipient"
        '
        'BloodIssueToolStripMenuItem
        '
        Me.BloodIssueToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodIssueToolStripMenuItem.Name = "BloodIssueToolStripMenuItem"
        Me.BloodIssueToolStripMenuItem.Size = New System.Drawing.Size(170, 42)
        Me.BloodIssueToolStripMenuItem.Text = "Blood Issue"
        '
        'StockToolStripMenuItem
        '
        Me.StockToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StockToolStripMenuItem.Name = "StockToolStripMenuItem"
        Me.StockToolStripMenuItem.Size = New System.Drawing.Size(95, 42)
        Me.StockToolStripMenuItem.Text = "Stock"
        '
        'CampToolStripMenuItem
        '
        Me.CampToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CampToolStripMenuItem.Name = "CampToolStripMenuItem"
        Me.CampToolStripMenuItem.Size = New System.Drawing.Size(100, 42)
        Me.CampToolStripMenuItem.Text = "Camp"
        '
        'QueriesToolStripMenuItem
        '
        Me.QueriesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Report1ToolStripMenuItem, Me.Report2ToolStripMenuItem, Me.Report3ToolStripMenuItem, Me.Report4ToolStripMenuItem})
        Me.QueriesToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.QueriesToolStripMenuItem.Name = "QueriesToolStripMenuItem"
        Me.QueriesToolStripMenuItem.Size = New System.Drawing.Size(123, 42)
        Me.QueriesToolStripMenuItem.Text = "Reports"
        '
        'Report1ToolStripMenuItem
        '
        Me.Report1ToolStripMenuItem.Name = "Report1ToolStripMenuItem"
        Me.Report1ToolStripMenuItem.Size = New System.Drawing.Size(513, 42)
        Me.Report1ToolStripMenuItem.Text = "Stock of Blood collected in Camp"
        '
        'Report2ToolStripMenuItem
        '
        Me.Report2ToolStripMenuItem.Name = "Report2ToolStripMenuItem"
        Me.Report2ToolStripMenuItem.Size = New System.Drawing.Size(513, 42)
        Me.Report2ToolStripMenuItem.Text = "People visited in Camp"
        '
        'Report3ToolStripMenuItem
        '
        Me.Report3ToolStripMenuItem.Name = "Report3ToolStripMenuItem"
        Me.Report3ToolStripMenuItem.Size = New System.Drawing.Size(513, 42)
        Me.Report3ToolStripMenuItem.Text = "Blood given to recipients"
        '
        'Report4ToolStripMenuItem
        '
        Me.Report4ToolStripMenuItem.Name = "Report4ToolStripMenuItem"
        Me.Report4ToolStripMenuItem.Size = New System.Drawing.Size(513, 42)
        Me.Report4ToolStripMenuItem.Text = "Donor donated Blood"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1521, 672)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "frmMain"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DonorRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecipientRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DonorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecipientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BloodIssueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StockToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CampToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QueriesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Report1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Report2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Report3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Report4ToolStripMenuItem As ToolStripMenuItem
End Class
