﻿Public Class frmMain
    Private Sub DonorRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DonorRegistrationToolStripMenuItem.Click
        Donor_Registration.Show()
    End Sub

    Private Sub RecipientRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RecipientRegistrationToolStripMenuItem.Click
        Recipient_Form.Show()
    End Sub

    Private Sub DonorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DonorToolStripMenuItem.Click
        frmDnr.Show()
    End Sub

    Private Sub RecipientToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RecipientToolStripMenuItem.Click
        frmRec.Show()
    End Sub

    Private Sub BloodIssueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BloodIssueToolStripMenuItem.Click
        frmBldIss.Show()
    End Sub

    Private Sub StockToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StockToolStripMenuItem.Click
        frmStk.Show()
    End Sub

    Private Sub CampToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CampToolStripMenuItem.Click
        frmCmp.Show()
    End Sub

    Private Sub Report1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Report1ToolStripMenuItem.Click
        frmRep1.Show()
    End Sub

    Private Sub Report2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Report2ToolStripMenuItem.Click
        frmRep2.Show()
    End Sub

    Private Sub Report3ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Report3ToolStripMenuItem.Click
        frmRep3.Show()
    End Sub

    Private Sub Report4ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Report4ToolStripMenuItem.Click
        frmRep4.Show()
    End Sub
End Class