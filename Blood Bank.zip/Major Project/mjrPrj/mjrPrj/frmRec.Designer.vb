﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRec
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblRec = New System.Windows.Forms.Label()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.lblIDE = New System.Windows.Forms.Label()
        Me.lblNme = New System.Windows.Forms.Label()
        Me.lblAeg = New System.Windows.Forms.Label()
        Me.lblAds = New System.Windows.Forms.Label()
        Me.lblCntNmb = New System.Windows.Forms.Label()
        Me.lblBldTyp = New System.Windows.Forms.Label()
        Me.btnSub = New System.Windows.Forms.Button()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.txtIDE = New System.Windows.Forms.TextBox()
        Me.TbRecBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbBldBnkSysDataSet10 = New mjrPrj.dbBldBnkSysDataSet10()
        Me.txtNme = New System.Windows.Forms.TextBox()
        Me.txtAeg = New System.Windows.Forms.TextBox()
        Me.txtAds = New System.Windows.Forms.TextBox()
        Me.txtCntNmb = New System.Windows.Forms.TextBox()
        Me.cmbBldTyp = New System.Windows.Forms.ComboBox()
        Me.lblDteRec = New System.Windows.Forms.Label()
        Me.dteTmePkr = New System.Windows.Forms.DateTimePicker()
        Me.lbldis = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AgeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactNumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BloodTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateOfRecievingDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TbRecTableAdapter = New mjrPrj.dbBldBnkSysDataSet10TableAdapters.tbRecTableAdapter()
        Me.lblRecLst = New System.Windows.Forms.Label()
        Me.cboRecLst = New System.Windows.Forms.ComboBox()
        CType(Me.TbRecBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbBldBnkSysDataSet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblRec
        '
        Me.lblRec.AutoSize = True
        Me.lblRec.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRec.Location = New System.Drawing.Point(12, 9)
        Me.lblRec.Name = "lblRec"
        Me.lblRec.Size = New System.Drawing.Size(142, 31)
        Me.lblRec.TabIndex = 4
        Me.lblRec.Text = "Recipient"
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(1408, 19)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 46)
        Me.btnCls.TabIndex = 15
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'lblIDE
        '
        Me.lblIDE.AutoSize = True
        Me.lblIDE.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIDE.Location = New System.Drawing.Point(177, 126)
        Me.lblIDE.Name = "lblIDE"
        Me.lblIDE.Size = New System.Drawing.Size(48, 37)
        Me.lblIDE.TabIndex = 16
        Me.lblIDE.Text = "ID"
        '
        'lblNme
        '
        Me.lblNme.AutoSize = True
        Me.lblNme.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNme.Location = New System.Drawing.Point(169, 192)
        Me.lblNme.Name = "lblNme"
        Me.lblNme.Size = New System.Drawing.Size(112, 37)
        Me.lblNme.TabIndex = 17
        Me.lblNme.Text = " Name"
        '
        'lblAeg
        '
        Me.lblAeg.AutoSize = True
        Me.lblAeg.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAeg.Location = New System.Drawing.Point(177, 260)
        Me.lblAeg.Name = "lblAeg"
        Me.lblAeg.Size = New System.Drawing.Size(74, 37)
        Me.lblAeg.TabIndex = 18
        Me.lblAeg.Text = "Age"
        '
        'lblAds
        '
        Me.lblAds.AutoSize = True
        Me.lblAds.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAds.Location = New System.Drawing.Point(169, 330)
        Me.lblAds.Name = "lblAds"
        Me.lblAds.Size = New System.Drawing.Size(135, 37)
        Me.lblAds.TabIndex = 19
        Me.lblAds.Text = "Address"
        '
        'lblCntNmb
        '
        Me.lblCntNmb.AutoSize = True
        Me.lblCntNmb.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCntNmb.Location = New System.Drawing.Point(126, 399)
        Me.lblCntNmb.Name = "lblCntNmb"
        Me.lblCntNmb.Size = New System.Drawing.Size(252, 37)
        Me.lblCntNmb.TabIndex = 21
        Me.lblCntNmb.Text = "Contact Number"
        '
        'lblBldTyp
        '
        Me.lblBldTyp.AutoSize = True
        Me.lblBldTyp.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldTyp.Location = New System.Drawing.Point(126, 474)
        Me.lblBldTyp.Name = "lblBldTyp"
        Me.lblBldTyp.Size = New System.Drawing.Size(178, 37)
        Me.lblBldTyp.TabIndex = 22
        Me.lblBldTyp.Text = "Blood Type"
        '
        'btnSub
        '
        Me.btnSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSub.Location = New System.Drawing.Point(92, 610)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(152, 53)
        Me.btnSub.TabIndex = 31
        Me.btnSub.Text = "SUBMIT"
        Me.btnSub.UseVisualStyleBackColor = True
        '
        'btnDel
        '
        Me.btnDel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDel.Location = New System.Drawing.Point(427, 610)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(169, 53)
        Me.btnDel.TabIndex = 33
        Me.btnDel.Text = "DELETE"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'txtIDE
        '
        Me.txtIDE.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "ID", True))
        Me.txtIDE.Location = New System.Drawing.Point(427, 126)
        Me.txtIDE.Name = "txtIDE"
        Me.txtIDE.Size = New System.Drawing.Size(161, 26)
        Me.txtIDE.TabIndex = 34
        '
        'TbRecBindingSource
        '
        Me.TbRecBindingSource.DataMember = "tbRec"
        Me.TbRecBindingSource.DataSource = Me.DbBldBnkSysDataSet10
        '
        'DbBldBnkSysDataSet10
        '
        Me.DbBldBnkSysDataSet10.DataSetName = "dbBldBnkSysDataSet10"
        Me.DbBldBnkSysDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtNme
        '
        Me.txtNme.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Name", True))
        Me.txtNme.Location = New System.Drawing.Point(427, 192)
        Me.txtNme.Name = "txtNme"
        Me.txtNme.Size = New System.Drawing.Size(161, 26)
        Me.txtNme.TabIndex = 35
        '
        'txtAeg
        '
        Me.txtAeg.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Age", True))
        Me.txtAeg.Location = New System.Drawing.Point(427, 251)
        Me.txtAeg.Name = "txtAeg"
        Me.txtAeg.Size = New System.Drawing.Size(161, 26)
        Me.txtAeg.TabIndex = 36
        '
        'txtAds
        '
        Me.txtAds.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Address", True))
        Me.txtAds.Location = New System.Drawing.Point(427, 330)
        Me.txtAds.Name = "txtAds"
        Me.txtAds.Size = New System.Drawing.Size(161, 26)
        Me.txtAds.TabIndex = 37
        '
        'txtCntNmb
        '
        Me.txtCntNmb.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Contact Number", True))
        Me.txtCntNmb.Location = New System.Drawing.Point(427, 399)
        Me.txtCntNmb.Name = "txtCntNmb"
        Me.txtCntNmb.Size = New System.Drawing.Size(161, 26)
        Me.txtCntNmb.TabIndex = 38
        '
        'cmbBldTyp
        '
        Me.cmbBldTyp.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Blood Type", True))
        Me.cmbBldTyp.FormattingEnabled = True
        Me.cmbBldTyp.Items.AddRange(New Object() {"A+", "0+", "B+", "AB+", "A-", "O-", "B-", "AB-"})
        Me.cmbBldTyp.Location = New System.Drawing.Point(427, 474)
        Me.cmbBldTyp.Name = "cmbBldTyp"
        Me.cmbBldTyp.Size = New System.Drawing.Size(161, 28)
        Me.cmbBldTyp.TabIndex = 39
        '
        'lblDteRec
        '
        Me.lblDteRec.AutoSize = True
        Me.lblDteRec.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDteRec.Location = New System.Drawing.Point(85, 542)
        Me.lblDteRec.Name = "lblDteRec"
        Me.lblDteRec.Size = New System.Drawing.Size(266, 37)
        Me.lblDteRec.TabIndex = 40
        Me.lblDteRec.Text = "Date of Recieving"
        '
        'dteTmePkr
        '
        Me.dteTmePkr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbRecBindingSource, "Date of recieving", True))
        Me.dteTmePkr.Location = New System.Drawing.Point(427, 542)
        Me.dteTmePkr.Name = "dteTmePkr"
        Me.dteTmePkr.Size = New System.Drawing.Size(196, 26)
        Me.dteTmePkr.TabIndex = 41
        '
        'lbldis
        '
        Me.lbldis.AutoSize = True
        Me.lbldis.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldis.Location = New System.Drawing.Point(943, 71)
        Me.lbldis.Name = "lbldis"
        Me.lbldis.Size = New System.Drawing.Size(253, 40)
        Me.lbldis.TabIndex = 42
        Me.lbldis.Text = "Recipient Data"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn, Me.AgeDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.ContactNumberDataGridViewTextBoxColumn, Me.BloodTypeDataGridViewTextBoxColumn, Me.DateOfRecievingDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TbRecBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(641, 137)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(891, 414)
        Me.DataGridView1.TabIndex = 43
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'AgeDataGridViewTextBoxColumn
        '
        Me.AgeDataGridViewTextBoxColumn.DataPropertyName = "Age"
        Me.AgeDataGridViewTextBoxColumn.HeaderText = "Age"
        Me.AgeDataGridViewTextBoxColumn.Name = "AgeDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'ContactNumberDataGridViewTextBoxColumn
        '
        Me.ContactNumberDataGridViewTextBoxColumn.DataPropertyName = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.HeaderText = "Contact Number"
        Me.ContactNumberDataGridViewTextBoxColumn.Name = "ContactNumberDataGridViewTextBoxColumn"
        '
        'BloodTypeDataGridViewTextBoxColumn
        '
        Me.BloodTypeDataGridViewTextBoxColumn.DataPropertyName = "Blood Type"
        Me.BloodTypeDataGridViewTextBoxColumn.HeaderText = "Blood Type"
        Me.BloodTypeDataGridViewTextBoxColumn.Name = "BloodTypeDataGridViewTextBoxColumn"
        '
        'DateOfRecievingDataGridViewTextBoxColumn
        '
        Me.DateOfRecievingDataGridViewTextBoxColumn.DataPropertyName = "Date of recieving"
        Me.DateOfRecievingDataGridViewTextBoxColumn.HeaderText = "Date of recieving"
        Me.DateOfRecievingDataGridViewTextBoxColumn.Name = "DateOfRecievingDataGridViewTextBoxColumn"
        '
        'TbRecTableAdapter
        '
        Me.TbRecTableAdapter.ClearBeforeFill = True
        '
        'lblRecLst
        '
        Me.lblRecLst.AutoSize = True
        Me.lblRecLst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecLst.Location = New System.Drawing.Point(169, 62)
        Me.lblRecLst.Name = "lblRecLst"
        Me.lblRecLst.Size = New System.Drawing.Size(207, 37)
        Me.lblRecLst.TabIndex = 47
        Me.lblRecLst.Text = "Recipient List"
        '
        'cboRecLst
        '
        Me.cboRecLst.FormattingEnabled = True
        Me.cboRecLst.Location = New System.Drawing.Point(424, 62)
        Me.cboRecLst.Name = "cboRecLst"
        Me.cboRecLst.Size = New System.Drawing.Size(164, 28)
        Me.cboRecLst.TabIndex = 48
        '
        'frmRec
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1544, 682)
        Me.Controls.Add(Me.cboRecLst)
        Me.Controls.Add(Me.lblRecLst)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lbldis)
        Me.Controls.Add(Me.dteTmePkr)
        Me.Controls.Add(Me.lblDteRec)
        Me.Controls.Add(Me.cmbBldTyp)
        Me.Controls.Add(Me.txtCntNmb)
        Me.Controls.Add(Me.txtAds)
        Me.Controls.Add(Me.txtAeg)
        Me.Controls.Add(Me.txtNme)
        Me.Controls.Add(Me.txtIDE)
        Me.Controls.Add(Me.btnDel)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.lblBldTyp)
        Me.Controls.Add(Me.lblCntNmb)
        Me.Controls.Add(Me.lblAds)
        Me.Controls.Add(Me.lblAeg)
        Me.Controls.Add(Me.lblNme)
        Me.Controls.Add(Me.lblIDE)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.lblRec)
        Me.Name = "frmRec"
        Me.Text = "frmRec"
        CType(Me.TbRecBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbBldBnkSysDataSet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblRec As Label
    Friend WithEvents btnCls As Button
    Friend WithEvents lblIDE As Label
    Friend WithEvents lblNme As Label
    Friend WithEvents lblAeg As Label
    Friend WithEvents lblAds As Label
    Friend WithEvents lblCntNmb As Label
    Friend WithEvents lblBldTyp As Label
    Friend WithEvents btnSub As Button
    Friend WithEvents btnDel As Button
    Friend WithEvents txtIDE As TextBox
    Friend WithEvents txtNme As TextBox
    Friend WithEvents txtAeg As TextBox
    Friend WithEvents txtAds As TextBox
    Friend WithEvents txtCntNmb As TextBox
    Friend WithEvents cmbBldTyp As ComboBox
    Friend WithEvents lblDteRec As Label
    Friend WithEvents dteTmePkr As DateTimePicker
    Friend WithEvents lbldis As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DbBldBnkSysDataSet10 As dbBldBnkSysDataSet10
    Friend WithEvents TbRecBindingSource As BindingSource
    Friend WithEvents TbRecTableAdapter As dbBldBnkSysDataSet10TableAdapters.tbRecTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AgeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ContactNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BloodTypeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateOfRecievingDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents lblRecLst As Label
    Friend WithEvents cboRecLst As ComboBox
End Class
