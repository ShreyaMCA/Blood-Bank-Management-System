﻿Imports System.Data.OleDb
Public Class frmRec
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub frmRec_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet10.tbRec' table. You can move, or remove it, as needed.
        Me.TbRecTableAdapter.Fill(Me.DbBldBnkSysDataSet10.tbRec)
        Call pConnectDB()
        Call pcboRec()
    End Sub

    Private Sub btnSub_Click(sender As Object, e As EventArgs) Handles btnSub.Click
        Try
            Dim sSql As String
            Dim Date11 As String = Format(dteTmePkr.Value, "dd-MM-yyyy")
            sSql = "insert into tbRec values('" & txtIDE.Text & "','" & txtNme.Text & "','" & txtAeg.Text & "','" & txtAds.Text & "','" & txtCntNmb.Text & "','" & cmbBldTyp.Text & "','" & Date11 & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtIDE.Text = " "
            txtNme.Text = " "
            txtAeg.Text = " "
            txtAds.Text = " "
            txtCntNmb.Text = " "
            cmbBldTyp.Text = " "
            MessageBox.Show(cmbBldTyp.SelectedItem & "is selected")
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnDel_Click(sender As Object, e As EventArgs) Handles btnDel.Click
        Try
            Dim sSql As String
            sSql = "delete * from tbRec where Name = '" & txtNme.Text & "'"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtIDE.Text = " "
            txtNme.Text = " "
            txtAeg.Text = " "
            txtAds.Text = " "
            txtCntNmb.Text = " "
            cmbBldTyp.Text = " "
            MessageBox.Show(cmbBldTyp.SelectedItem & "is deleted")
            MsgBox("Record is deleted!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
    Private Sub cboRecLst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRecLst.SelectedIndexChanged
        Dim sSql As String
        sSql = "select * from tbRec where Name = '" & txtNme.Text & "'"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        dr.Read()
        txtIDE.Text = dr.Item("ID")
        txtNme.Text = dr.Item("Name")
        txtAeg.Text = dr.Item("Age")
        txtAds.Text = dr.Item("Address")
        txtCntNmb.Text = dr.Item("Contact Number")
        cmbBldTyp.Text = dr.Item("Blood Type")
        dteTmePkr.Text = dr.Item("Date of recieving")
    End Sub
    Private Sub pcboRec()
        cboRecLst.Items.Clear()
        Dim sSql As String
        sSql = "select * from tbRec"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboRecLst.Items.Add(dr.Item("Name"))
            'MessageBox.Show(dr.Item("empNam"))
        End While
        cboRecLst.SelectedIndex = 0
    End Sub
End Class