﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRegs))
        Me.lblDsp = New System.Windows.Forms.Label()
        Me.btnDnrReg = New System.Windows.Forms.Button()
        Me.btnRecReg = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblDsp
        '
        Me.lblDsp.AutoSize = True
        Me.lblDsp.BackColor = System.Drawing.Color.Transparent
        Me.lblDsp.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDsp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblDsp.Location = New System.Drawing.Point(93, 35)
        Me.lblDsp.Name = "lblDsp"
        Me.lblDsp.Size = New System.Drawing.Size(502, 64)
        Me.lblDsp.TabIndex = 0
        Me.lblDsp.Text = "WELCOME USER!"
        '
        'btnDnrReg
        '
        Me.btnDnrReg.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDnrReg.Location = New System.Drawing.Point(628, 420)
        Me.btnDnrReg.Name = "btnDnrReg"
        Me.btnDnrReg.Size = New System.Drawing.Size(252, 120)
        Me.btnDnrReg.TabIndex = 1
        Me.btnDnrReg.Text = "Donor Registration"
        Me.btnDnrReg.UseVisualStyleBackColor = True
        '
        'btnRecReg
        '
        Me.btnRecReg.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRecReg.Location = New System.Drawing.Point(628, 562)
        Me.btnRecReg.Name = "btnRecReg"
        Me.btnRecReg.Size = New System.Drawing.Size(252, 116)
        Me.btnRecReg.TabIndex = 2
        Me.btnRecReg.Text = "Recipient Registration"
        Me.btnRecReg.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(797, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(134, 47)
        Me.btnCls.TabIndex = 3
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'frmRegs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(943, 690)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnRecReg)
        Me.Controls.Add(Me.btnDnrReg)
        Me.Controls.Add(Me.lblDsp)
        Me.Name = "frmRegs"
        Me.Text = "frmRegs"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDsp As Label
    Friend WithEvents btnDnrReg As Button
    Friend WithEvents btnRecReg As Button
    Friend WithEvents btnCls As Button
End Class
