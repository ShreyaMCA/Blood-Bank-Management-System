﻿Public Class frmRegs
    Private Sub frmRegs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        frmMain.Show()
    End Sub

    Private Sub btnDnrReg_Click(sender As Object, e As EventArgs) Handles btnDnrReg.Click
        Donor_Registration.Show()
    End Sub

    Private Sub btnRecReg_Click(sender As Object, e As EventArgs) Handles btnRecReg.Click
        Recipient_Form.Show()
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
End Class