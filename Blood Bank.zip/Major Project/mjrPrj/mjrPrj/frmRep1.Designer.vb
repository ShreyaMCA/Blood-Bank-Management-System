﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRep1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lblDis = New System.Windows.Forms.Label()
        Me.btnShw = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(187, 118)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(815, 446)
        Me.DataGridView1.TabIndex = 0
        '
        'lblDis
        '
        Me.lblDis.AutoSize = True
        Me.lblDis.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDis.Location = New System.Drawing.Point(338, 54)
        Me.lblDis.Name = "lblDis"
        Me.lblDis.Size = New System.Drawing.Size(494, 37)
        Me.lblDis.TabIndex = 1
        Me.lblDis.Text = "Stock of Blood Collected in Camp"
        '
        'btnShw
        '
        Me.btnShw.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShw.Location = New System.Drawing.Point(514, 581)
        Me.btnShw.Name = "btnShw"
        Me.btnShw.Size = New System.Drawing.Size(178, 66)
        Me.btnShw.TabIndex = 2
        Me.btnShw.Text = "SHOW"
        Me.btnShw.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(981, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(125, 53)
        Me.btnCls.TabIndex = 3
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'frmRep1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1133, 670)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnShw)
        Me.Controls.Add(Me.lblDis)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmRep1"
        Me.Text = "frmRep1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblDis As Label
    Friend WithEvents btnShw As Button
    Friend WithEvents btnCls As Button
End Class
