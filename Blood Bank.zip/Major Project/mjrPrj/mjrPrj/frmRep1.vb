﻿Imports System.Data.OleDb
Public Class frmRep1
    Private Sub frmRep1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call pConnectDB()
    End Sub

    Private Sub btnShw_Click(sender As Object, e As EventArgs) Handles btnShw.Click
        Dim sSql As String
        sSql = "Select t2.ID,Venue,City,Organizer,Blood_Quantity from tbCmp AS t1,tbStk AS t2 where t2.ID=t1.ID"
        Dim adp As New OleDbDataAdapter(sSql, dbcon)
        Dim ds As New DataSet
        adp.Fill(ds, "tbCmp")
        DataGridView1.DataSource = ds.Tables(0)
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
End Class