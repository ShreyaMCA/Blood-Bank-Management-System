﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRep3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDis = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.btnShw = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDis
        '
        Me.lblDis.AutoSize = True
        Me.lblDis.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDis.Location = New System.Drawing.Point(243, 18)
        Me.lblDis.Name = "lblDis"
        Me.lblDis.Size = New System.Drawing.Size(382, 37)
        Me.lblDis.TabIndex = 3
        Me.lblDis.Text = "Blood Given to Recipients"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(50, 84)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 28
        Me.DataGridView3.Size = New System.Drawing.Size(815, 446)
        Me.DataGridView3.TabIndex = 4
        '
        'btnShw
        '
        Me.btnShw.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShw.Location = New System.Drawing.Point(349, 546)
        Me.btnShw.Name = "btnShw"
        Me.btnShw.Size = New System.Drawing.Size(178, 66)
        Me.btnShw.TabIndex = 5
        Me.btnShw.Text = "SHOW"
        Me.btnShw.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(777, 11)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(125, 53)
        Me.btnCls.TabIndex = 6
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'frmRep3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(914, 624)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnShw)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.lblDis)
        Me.Name = "frmRep3"
        Me.Text = "frmRep3"
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDis As Label
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents btnShw As Button
    Friend WithEvents btnCls As Button
End Class
