﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRep4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDsp = New System.Windows.Forms.Label()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.btnShw = New System.Windows.Forms.Button()
        Me.btnCls = New System.Windows.Forms.Button()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDsp
        '
        Me.lblDsp.AutoSize = True
        Me.lblDsp.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDsp.Location = New System.Drawing.Point(276, 33)
        Me.lblDsp.Name = "lblDsp"
        Me.lblDsp.Size = New System.Drawing.Size(326, 37)
        Me.lblDsp.TabIndex = 4
        Me.lblDsp.Text = "Donor Donated Blood"
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(62, 87)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowTemplate.Height = 28
        Me.DataGridView4.Size = New System.Drawing.Size(815, 446)
        Me.DataGridView4.TabIndex = 5
        '
        'btnShw
        '
        Me.btnShw.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShw.Location = New System.Drawing.Point(368, 551)
        Me.btnShw.Name = "btnShw"
        Me.btnShw.Size = New System.Drawing.Size(178, 66)
        Me.btnShw.TabIndex = 6
        Me.btnShw.Text = "SHOW"
        Me.btnShw.UseVisualStyleBackColor = True
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(803, 12)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(125, 53)
        Me.btnCls.TabIndex = 7
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'frmRep4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(940, 629)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.btnShw)
        Me.Controls.Add(Me.DataGridView4)
        Me.Controls.Add(Me.lblDsp)
        Me.Name = "frmRep4"
        Me.Text = "frmRep4"
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDsp As Label
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents btnShw As Button
    Friend WithEvents btnCls As Button
End Class
