﻿Imports System.Data.OleDb
Public Class frmRep4
    Private Sub frmRep4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call pConnectDB()
    End Sub

    Private Sub btnShw_Click(sender As Object, e As EventArgs) Handles btnShw.Click
        Dim sSql As String
        sSql = "Select t2.ID,Type_of_Blood,Blood_Quantity,Name,Age from tbStk AS t1,tbDnr AS t2 where t2.ID=t1.ID"
        Dim adp As New OleDbDataAdapter(sSql, dbcon)
        Dim ds As New DataSet
        adp.Fill(ds, "tbStk")
        DataGridView4.DataSource = ds.Tables(0)
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
End Class