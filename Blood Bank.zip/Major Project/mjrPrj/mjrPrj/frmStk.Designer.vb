﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmStk
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblStk = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblTypBld = New System.Windows.Forms.Label()
        Me.lblBldQty = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.TbStkBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbBldBnkSysDataSet5 = New mjrPrj.dbBldBnkSysDataSet5()
        Me.cmbBldType = New System.Windows.Forms.ComboBox()
        Me.txtBldQty = New System.Windows.Forms.TextBox()
        Me.btnSmt = New System.Windows.Forms.Button()
        Me.lblDis = New System.Windows.Forms.Label()
        Me.btnCls = New System.Windows.Forms.Button()
        Me.lblExpDte = New System.Windows.Forms.Label()
        Me.dteTmePkr = New System.Windows.Forms.DateTimePicker()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeofBloodDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BloodQuantityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExpiryDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TbStkTableAdapter = New mjrPrj.dbBldBnkSysDataSet5TableAdapters.tbStkTableAdapter()
        Me.lblStkLst = New System.Windows.Forms.Label()
        Me.cboStkLst = New System.Windows.Forms.ComboBox()
        CType(Me.TbStkBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbBldBnkSysDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblStk
        '
        Me.lblStk.AutoSize = True
        Me.lblStk.Font = New System.Drawing.Font("Lucida Handwriting", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStk.Location = New System.Drawing.Point(22, 20)
        Me.lblStk.Name = "lblStk"
        Me.lblStk.Size = New System.Drawing.Size(84, 31)
        Me.lblStk.TabIndex = 3
        Me.lblStk.Text = "Stock"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(141, 168)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(48, 37)
        Me.lblID.TabIndex = 5
        Me.lblID.Text = "ID"
        '
        'lblTypBld
        '
        Me.lblTypBld.AutoSize = True
        Me.lblTypBld.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTypBld.Location = New System.Drawing.Point(108, 259)
        Me.lblTypBld.Name = "lblTypBld"
        Me.lblTypBld.Size = New System.Drawing.Size(214, 37)
        Me.lblTypBld.TabIndex = 6
        Me.lblTypBld.Text = "Type of Blood"
        '
        'lblBldQty
        '
        Me.lblBldQty.AutoSize = True
        Me.lblBldQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBldQty.Location = New System.Drawing.Point(108, 348)
        Me.lblBldQty.Name = "lblBldQty"
        Me.lblBldQty.Size = New System.Drawing.Size(227, 37)
        Me.lblBldQty.TabIndex = 7
        Me.lblBldQty.Text = "Blood Quantity"
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbStkBindingSource, "ID", True))
        Me.txtID.Location = New System.Drawing.Point(395, 178)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(181, 26)
        Me.txtID.TabIndex = 9
        '
        'TbStkBindingSource
        '
        Me.TbStkBindingSource.DataMember = "tbStk"
        Me.TbStkBindingSource.DataSource = Me.DbBldBnkSysDataSet5
        '
        'DbBldBnkSysDataSet5
        '
        Me.DbBldBnkSysDataSet5.DataSetName = "dbBldBnkSysDataSet5"
        Me.DbBldBnkSysDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbBldType
        '
        Me.cmbBldType.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbStkBindingSource, "Type_of_Blood", True))
        Me.cmbBldType.FormattingEnabled = True
        Me.cmbBldType.Items.AddRange(New Object() {"A+", "0+", "B+", "AB+", "A-", "O-", "B-", "AB-"})
        Me.cmbBldType.Location = New System.Drawing.Point(395, 259)
        Me.cmbBldType.Name = "cmbBldType"
        Me.cmbBldType.Size = New System.Drawing.Size(181, 28)
        Me.cmbBldType.TabIndex = 10
        '
        'txtBldQty
        '
        Me.txtBldQty.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbStkBindingSource, "Blood_Quantity", True))
        Me.txtBldQty.Location = New System.Drawing.Point(395, 348)
        Me.txtBldQty.Name = "txtBldQty"
        Me.txtBldQty.Size = New System.Drawing.Size(181, 26)
        Me.txtBldQty.TabIndex = 11
        '
        'btnSmt
        '
        Me.btnSmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSmt.Location = New System.Drawing.Point(196, 518)
        Me.btnSmt.Name = "btnSmt"
        Me.btnSmt.Size = New System.Drawing.Size(152, 53)
        Me.btnSmt.TabIndex = 13
        Me.btnSmt.Text = "SUBMIT"
        Me.btnSmt.UseVisualStyleBackColor = True
        '
        'lblDis
        '
        Me.lblDis.AutoSize = True
        Me.lblDis.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDis.Location = New System.Drawing.Point(785, 99)
        Me.lblDis.Name = "lblDis"
        Me.lblDis.Size = New System.Drawing.Size(332, 46)
        Me.lblDis.TabIndex = 15
        Me.lblDis.Text = "Stock Information"
        '
        'btnCls
        '
        Me.btnCls.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCls.Location = New System.Drawing.Point(1229, 20)
        Me.btnCls.Name = "btnCls"
        Me.btnCls.Size = New System.Drawing.Size(124, 52)
        Me.btnCls.TabIndex = 16
        Me.btnCls.Text = "Close"
        Me.btnCls.UseVisualStyleBackColor = True
        '
        'lblExpDte
        '
        Me.lblExpDte.AutoSize = True
        Me.lblExpDte.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExpDte.Location = New System.Drawing.Point(121, 431)
        Me.lblExpDte.Name = "lblExpDte"
        Me.lblExpDte.Size = New System.Drawing.Size(180, 37)
        Me.lblExpDte.TabIndex = 17
        Me.lblExpDte.Text = "Expiry Date"
        '
        'dteTmePkr
        '
        Me.dteTmePkr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TbStkBindingSource, "Expiry_Date", True))
        Me.dteTmePkr.Location = New System.Drawing.Point(395, 431)
        Me.dteTmePkr.Name = "dteTmePkr"
        Me.dteTmePkr.Size = New System.Drawing.Size(196, 26)
        Me.dteTmePkr.TabIndex = 18
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.TypeofBloodDataGridViewTextBoxColumn, Me.BloodQuantityDataGridViewTextBoxColumn, Me.ExpiryDateDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TbStkBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(652, 183)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(900, 400)
        Me.DataGridView1.TabIndex = 19
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'TypeofBloodDataGridViewTextBoxColumn
        '
        Me.TypeofBloodDataGridViewTextBoxColumn.DataPropertyName = "Type_of_Blood"
        Me.TypeofBloodDataGridViewTextBoxColumn.HeaderText = "Type_of_Blood"
        Me.TypeofBloodDataGridViewTextBoxColumn.Name = "TypeofBloodDataGridViewTextBoxColumn"
        '
        'BloodQuantityDataGridViewTextBoxColumn
        '
        Me.BloodQuantityDataGridViewTextBoxColumn.DataPropertyName = "Blood_Quantity"
        Me.BloodQuantityDataGridViewTextBoxColumn.HeaderText = "Blood_Quantity"
        Me.BloodQuantityDataGridViewTextBoxColumn.Name = "BloodQuantityDataGridViewTextBoxColumn"
        '
        'ExpiryDateDataGridViewTextBoxColumn
        '
        Me.ExpiryDateDataGridViewTextBoxColumn.DataPropertyName = "Expiry_Date"
        Me.ExpiryDateDataGridViewTextBoxColumn.HeaderText = "Expiry_Date"
        Me.ExpiryDateDataGridViewTextBoxColumn.Name = "ExpiryDateDataGridViewTextBoxColumn"
        '
        'TbStkTableAdapter
        '
        Me.TbStkTableAdapter.ClearBeforeFill = True
        '
        'lblStkLst
        '
        Me.lblStkLst.AutoSize = True
        Me.lblStkLst.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStkLst.Location = New System.Drawing.Point(121, 86)
        Me.lblStkLst.Name = "lblStkLst"
        Me.lblStkLst.Size = New System.Drawing.Size(156, 37)
        Me.lblStkLst.TabIndex = 48
        Me.lblStkLst.Text = "Stock List"
        '
        'cboStkLst
        '
        Me.cboStkLst.FormattingEnabled = True
        Me.cboStkLst.Location = New System.Drawing.Point(395, 96)
        Me.cboStkLst.Name = "cboStkLst"
        Me.cboStkLst.Size = New System.Drawing.Size(181, 28)
        Me.cboStkLst.TabIndex = 49
        '
        'frmStk
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(1534, 611)
        Me.Controls.Add(Me.cboStkLst)
        Me.Controls.Add(Me.lblStkLst)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.dteTmePkr)
        Me.Controls.Add(Me.lblExpDte)
        Me.Controls.Add(Me.btnCls)
        Me.Controls.Add(Me.lblDis)
        Me.Controls.Add(Me.btnSmt)
        Me.Controls.Add(Me.txtBldQty)
        Me.Controls.Add(Me.cmbBldType)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblBldQty)
        Me.Controls.Add(Me.lblTypBld)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.lblStk)
        Me.Name = "frmStk"
        Me.Text = "frmStk"
        CType(Me.TbStkBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbBldBnkSysDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblStk As Label
    Friend WithEvents lblID As Label
    Friend WithEvents lblTypBld As Label
    Friend WithEvents lblBldQty As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents cmbBldType As ComboBox
    Friend WithEvents txtBldQty As TextBox
    Friend WithEvents btnSmt As Button
    Friend WithEvents lblDis As Label
    Friend WithEvents btnCls As Button
    Friend WithEvents lblExpDte As Label
    Friend WithEvents dteTmePkr As DateTimePicker
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DbBldBnkSysDataSet5 As dbBldBnkSysDataSet5
    Friend WithEvents TbStkBindingSource As BindingSource
    Friend WithEvents TbStkTableAdapter As dbBldBnkSysDataSet5TableAdapters.tbStkTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TypeofBloodDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BloodQuantityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ExpiryDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents lblStkLst As Label
    Friend WithEvents cboStkLst As ComboBox
End Class
