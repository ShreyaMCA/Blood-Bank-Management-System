﻿Imports System.Data.OleDb
Public Class frmStk
    Dim cmd As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub frmStk_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet5.tbStk' table. You can move, or remove it, as needed.
        'Me.TbStkTableAdapter.Fill(Me.DbBldBnkSysDataSet5.tbStk)
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet4.tbStk' table. You can move, or remove it, as needed.
        'Me.TbStkTableAdapter1.Fill(Me.DbBldBnkSysDataSet4.tbStk)
        'TODO: This line of code loads data into the 'DbBldBnkSysDataSet.tbStk' table. You can move, or remove it, as needed.
        Me.TbStkTableAdapter.Fill(Me.DbBldBnkSysDataSet5.tbStk)
        Call pConnectDB()
        Call pcboStk()
    End Sub

    Private Sub btnSmt_Click(sender As Object, e As EventArgs) Handles btnSmt.Click
        Try
            Dim Date11 As String = Format(dteTmePkr.Value, "dd-MM-yyyy")
            Dim sSql As String
            sSql = "insert into tbStk values('" & txtID.Text & "','" & cmbBldType.Text & "','" & txtBldQty.Text & "','" & Date11 & "')"
            cmd = New OleDbCommand(sSql, dbcon)
            cmd.ExecuteNonQuery()
            txtID.Text = " "
            cmbBldType.Text = " "
            txtBldQty.Text = " "
            MessageBox.Show(cmbBldType.SelectedItem & "is selected")
            MsgBox("You are registered successfully!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'dbcon.Close()
        End Try
    End Sub

    Private Sub btnCls_Click(sender As Object, e As EventArgs) Handles btnCls.Click
        Me.Close()
    End Sub
    Private Sub cboStkLst_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStkLst.SelectedIndexChanged
        Dim sSql As String
        sSql = "select * from tbStk where Type_of_Blood = '" & cmbBldType.Text & "'"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        dr.Read()
        txtID.Text = dr.Item("ID")
        cmbBldType.Text = dr.Item("Type_of_Blood")
        txtBldQty.Text = dr.Item("Blood_Quantity")
        dteTmePkr.Text = dr.Item("Expiry_Date")
    End Sub
    Private Sub pcboStk()
        cboStkLst.Items.Clear()
        Dim sSql As String
        sSql = "select * from tbStk"
        cmd = New OleDbCommand(sSql, dbcon)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboStkLst.Items.Add(dr.Item("Type_of_Blood"))
            'MessageBox.Show(dr.Item("empNam"))
        End While
        cboStkLst.SelectedIndex = 0
    End Sub
End Class