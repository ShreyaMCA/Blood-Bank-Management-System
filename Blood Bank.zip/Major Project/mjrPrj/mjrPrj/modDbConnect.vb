﻿Imports System.Data.OleDb
Module modDbConnect
    Public dbcon As New OleDbConnection
    Public Sub pConnectDB()
        If dbcon.State = ConnectionState.Closed Then
            dbcon.ConnectionString = " Provider=Microsoft.Jet.OLEDB.4.0;Data Source= C:\Users\HP\Desktop\Major Project\dbBldBnkSys.mdb"
            dbcon.Open()
        End If
    End Sub
    Public Sub pDisconnectDB()
        If dbcon.State = ConnectionState.Open Then
            dbcon.Close()
        End If
    End Sub
End Module